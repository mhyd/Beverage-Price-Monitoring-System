// VBConversions Note: VB project level imports
using System.Collections.Generic;
using System;
using System.Linq;
using System.Drawing;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Data;
using System.Xml.Linq;
using Microsoft.VisualBasic;
using System.Collections;
using System.Windows.Forms;
using System.Data.OleDb;
// End of VB project level imports

using System.Data.SqlClient;
using System.IO;

namespace WindowsApp1
{
	sealed class Module_SQL
	{
        
        public static bool SQL_Logging = false;
        public static string SQLServer;
		public static string SQLDatabaseName;
		public static string SQLUserName;
		public static string SQLPassword;
		
		public static string SQLConnectionString;
		
		public static string Connectionisgood = "Y";
		
		
		public static void Setup_SQL_Connection(string IniFilename, ref string ResponseMessage)
		{
			
			
			if (SetupPage.Load_SQL_Connection(IniFilename, ref SQLServer, ref SQLDatabaseName, ref SQLUserName, ref SQLPassword, ref ResponseMessage))
			{
				// form the sql connection
				//SQLConnectionString = Connectivity.SQLConnectionString(SQLServer, SQLDatabaseName, SQLUserName, SQLPassword);
				
				SQLConnectionString = "server = " + SQLServer + ";database = " + SQLDatabaseName + ";USER ID=" + SQLUserName + ";Password=" + SQLPassword;
				
			}
			else
			{
				Connectionisgood = "N";
			}
		}

        
        public static bool Execute_EmbeddedSQLScriptFile(string EmbeddedTextFile, System.Data.OleDb.OleDbConnection oledbConn)
        {

            string SQLScriptFile = null;
            SQLScriptFile = LoadEmbeddedTextFile(EmbeddedTextFile);

            // search for "go--" and replace with a pipe character to allow for splitting
            string SQLScriptFile_0 = SQLScriptFile.Replace("go--", "|");

            // Split the string on the pipe character
            string[] SQLParts = SQLScriptFile_0.Split('|');

            // Loop through result strings with For Each
            string part = null;
            foreach (string part_loopVariable in SQLParts)
            {
                part = part_loopVariable;
                Exec_Query(part, oledbConn);
            }

            return true;

        }
        public static string LoadEmbeddedTextFile(string EmbeddedTextFile)
        {

            string FileString = null;
            System.Reflection.Assembly executing_assembly = System.Reflection.Assembly.GetEntryAssembly();

            dynamic ResourcesNames = executing_assembly.GetManifestResourceNames();

            string ResourceName = "WindowsApp1." + EmbeddedTextFile;
            Stream text_stream = executing_assembly.GetManifestResourceStream(ResourceName);
            
            StreamReader reader = new StreamReader(text_stream);

            FileString = reader.ReadToEnd();

            return FileString;
        }
        public static void Exec_Query(string SqlQuery, System.Data.OleDb.OleDbConnection oledbConn)
        {


            // log the sql 
            if (SQL_Logging)
            {
                System.IO.StreamWriter objWriter = new System.IO.StreamWriter(Application.ExecutablePath.Substring(0, Application.ExecutablePath.Length - 4) + ".log", true);
                objWriter.WriteLine(SqlQuery);
                objWriter.Close();
            }
            //DebugMode

            string ErrorMessage = null;
            bool SQLConnectionOK = false;

            try
            {

                oledbConn.Open();
                string ServerVersion = oledbConn.ServerVersion;
                SQLConnectionOK = true;
            }
            catch (Exception ex)
            {
                SQLConnectionOK = false;
            }

            System.Data.OleDb.OleDbCommand oledbCmd = new System.Data.OleDb.OleDbCommand(SqlQuery, oledbConn);

            //only execute the sql command if the "open" command was ok.
            if (SQLConnectionOK)
            {
                try
                {
                    oledbCmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    ErrorMessage = ex.Message + Constants.vbCrLf + Constants.vbCrLf + SqlQuery;
                    MessageBox.Show(ErrorMessage, "Program SQL Error");
                }

            }

            oledbConn.Close();

        }

    }

}
