// VBConversions Note: VB project level imports
using System.Collections.Generic;
using System;
using System.Linq;
using System.Drawing;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Data;
using System.Xml.Linq;
using Microsoft.VisualBasic;
using System.Collections;
using System.Windows.Forms;
// End of VB project level imports

using System.Text;


namespace WindowsApp1
{
	sealed class SetupPage
	{
		
		public static bool Load_SQL_Connection(string IniFilename, ref string SQLServer, ref string SQLDatabaseName, ref string SQLUserName, ref string SQLPassword, ref string ResponseMessage)
		{
			
			bool result = false;
			string SQLPasswordHashed = "";
			
			//' set up the INI file as the Exe Name + .ini
			//Dim IniFile As New IniFile(Application.ExecutablePath.Substring(0, Application.ExecutablePath.Length - 4) & ".ini")
			//' Dim iniFileSection As String = "SQLConnection"
			
            string AppFilePathURI = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
            string AppFilePath = new Uri(AppFilePathURI).LocalPath;
            IniFile IniFile = new IniFile(AppFilePath + "\\" + IniFilename);

            SQLServer = IniFile.GetString("SQLConnection", "SQLServer", "");
			SQLDatabaseName = IniFile.GetString("SQLConnection", "SQLDatabaseName", "");
			SQLUserName = IniFile.GetString("SQLConnection", "SQLUserName", "");
			SQLPasswordHashed = IniFile.GetString("SQLConnection", "SQLPassword", "");
			if (SQLDatabaseName.Length > 0)
			{
				
				result = true;
			}
			
			try // try to convert the hashed SQL password.
			{
				SQLPassword = Encoding.UTF8.GetString(Convert.FromBase64String(SQLPasswordHashed));
			}
			catch (Exception)
			{
				// Catch the exception that would occur if its not valid.
				SQLPassword = "";
				ResponseMessage = "The SQL Server Password is invalid." + "\r\n" + "\r\n";
				ResponseMessage = ResponseMessage + "Please enter the password again., ";
				
			}
			
			return result;
		}
	}
	
}
