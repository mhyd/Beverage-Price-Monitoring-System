using System;
using System.Data;
using Microsoft.VisualBasic;
using System.Windows.Forms;
using System.Text;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.SqlClient;
using Microsoft.CSharp;
using System.Collections.Generic;
using System.Reflection;
using System.IO;

namespace WindowsApp1
{

    public partial class Form1
    {
        string HasDataBase = "N";
        string Pass = "";
        public Form1()
        {

            InitializeComponent();
            //Added to support default instance behavour in C#
            if (defaultInstance == null)
                defaultInstance = this;


        }

        #region Default Instance

        private static Form1 defaultInstance;

        /// <summary>
        /// Added by the VB.Net to C# Converter to support default instance behavour in C#
        /// </summary>
        public static Form1 Default
        {
            get
            {
                if (defaultInstance == null)
                {
                    defaultInstance = new Form1();
                    defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
                }

                return defaultInstance;
            }
            set
            {
                defaultInstance = value;
            }
        }

        static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
        {
            defaultInstance = null;
        }

        #endregion

        public bool LoadiniFile()
        {


            bool result = false;

            IniFile IniFile = new IniFile(Application.ExecutablePath.Substring(0, Application.ExecutablePath.Length - 4) + ".ini");

            Module_SQL.SQLServer = IniFile.GetString("SQLConnection", "SQLServer", "");
            IniFile.WriteString("SQLConnection", "SQLServer", Module_SQL.SQLServer);

            Module_SQL.SQLDatabaseName = IniFile.GetString("SQLConnection", "SQLDatabaseName", "");
            IniFile.WriteString("SQLConnection", "SQLDatabaseName", Module_SQL.SQLDatabaseName);

            Module_SQL.SQLUserName = IniFile.GetString("SQLConnection", "SQLUserName", "");
            IniFile.WriteString("SQLConnection", "SQLUserName", Module_SQL.SQLUserName);

            Module_SQL.SQLPassword = IniFile.GetString("SQLConnection", "SQLPassword", "");
            IniFile.WriteString("SQLConnection", "SQLPassword", Module_SQL.SQLPassword);

            HasDataBase = IniFile.GetString("DataBase", "HasDataBase", HasDataBase);
            IniFile.WriteString("DataBase", "DataBase", HasDataBase);

            return result;

        }

        public void SQLSaveButton_Click(object sender, EventArgs e)
        {
            // Save the SQL connection data to the ini file


            string SQLPasswordHashed = "";

            IniFile IniFile = new IniFile(Application.ExecutablePath.Substring(0, Application.ExecutablePath.Length - 4) + ".ini");

            IniFile.WriteString("SQLConnection", "SQLServer", SQLServerTextBox.Text.ToString());
            IniFile.WriteString("SQLConnection", "SQLDatabaseName", SQLDatabaseTextBox.Text.ToString());
            IniFile.WriteString("SQLConnection", "SQLUserName", SQLUserNameTextBox.Text.ToString());

            SQLPasswordHashed = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLPassTextBox.Text));

            IniFile.WriteString("SQLConnection", "SQLPassword", SQLPasswordHashed);

            Interaction.MsgBox("NameOfProject will now close and restart to ensure that saved changes take effect.", MsgBoxStyle.Exclamation, "NameOfProject will restart.");
            Application.Restart();

        }
        public void SQLTestConnectionButton_Click(object sender, EventArgs e)
        {
            // This subroutine is used to test the SQL connection details and select a suitable result image

            Cursor = Cursors.WaitCursor;
            string Password = "";
            // if something has been typed into the password text box then use it. otherwise use the saved password
            if (SQLPassTextBox.TextLength > 0)
            {
                Password = SQLPassTextBox.Text;
                Pass = Password;
            }
            else
            {
                Password = Module_SQL.SQLPassword;
            }

            if (Connectivity.IsSQLConnectionOK(SQLServerTextBox.Text, SQLDatabaseTextBox.Text, SQLUserNameTextBox.Text, Password))
            {
                // SQL Connection must be ok, so proceed.
                SQLTickPictureBox.Visible = true;
                SQLCROSSPictureBox.Visible = false;
            }
            else
            {
                // SQL Connection Failure
                SQLTickPictureBox.Visible = false;
                SQLCROSSPictureBox.Visible = true;
            }
            Cursor = Cursors.Default;
        }

        public void Form1_Load(System.Object sender, System.EventArgs e)
        {
            IniFile IniFile = new IniFile(Application.ExecutablePath.Substring(0, Application.ExecutablePath.Length - 4) + ".ini");
            string AppFileName = System.IO.Path.GetFileName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
            string INIFile = AppFileName.Substring(0, AppFileName.Length - 4) + ".ini";
            string ResponseMesage = "";
            Module_SQL.Setup_SQL_Connection(INIFile, ref ResponseMesage);

            LoadiniFile();


            if (Module_SQL.Connectionisgood == "N")
            {
                SQLTickPictureBox.Visible = false;
                SQLCROSSPictureBox.Visible = true;
                HasDataBase = "N";
                IniFile.WriteString("DataBase", "DataBase", HasDataBase);
            }


            if (Module_SQL.Connectionisgood == "Y")
            {

                InstallDataBase();
            }
            SQLServerTextBox.Text = Module_SQL.SQLServer.ToString();
            SQLDatabaseTextBox.Text = Module_SQL.SQLDatabaseName.ToString();
            SQLUserNameTextBox.Text = Module_SQL.SQLUserName.ToString();

            tabControl1.TabPages.Remove(tabPage2);

        }
        public void InstallDataBase()
        {


            if (HasDataBase == "N")
            {

                string Password = Encoding.UTF8.GetString(Convert.FromBase64String(Module_SQL.SQLPassword));

                string Local_SQLConnectionString;
                Local_SQLConnectionString = Connectivity.SQLConnectionString(Module_SQL.SQLServer, Module_SQL.SQLDatabaseName, Module_SQL.SQLUserName, Password);
                

                

                System.Data.OleDb.OleDbConnection oledbConn = new System.Data.OleDb.OleDbConnection(Local_SQLConnectionString);


                Module_SQL.Execute_EmbeddedSQLScriptFile("InstallScript.txt", oledbConn);
                
               
                HasDataBase = "Y";
                IniFile IniFile = new IniFile(Application.ExecutablePath.Substring(0, Application.ExecutablePath.Length - 4) + ".ini");
                IniFile.WriteString("DataBase", "DataBase", HasDataBase);

            }
            if (HasDataBase == "" )
            {
                HasDataBase = "N";
                IniFile IniFile = new IniFile(Application.ExecutablePath.Substring(0, Application.ExecutablePath.Length - 4) + ".ini");
                IniFile.WriteString("DataBase", "DataBase", HasDataBase);
            }
        }



        private void SaveDataToDatabasebutton_Click(object sender, EventArgs e)
        {


            Cursor.Current = Cursors.WaitCursor;
            ExcelExport.ReadExcel_Coles();
            Cursor.Current = Cursors.Default;
            System.Windows.Forms.Application.Exit();

        }


        private void button3_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            ExcelExport.ReadExcel();
            Cursor.Current = Cursors.Default;
            System.Windows.Forms.Application.Exit();

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string StartDate = dateTimePicker1.Value.ToString("yyyMMdd");
            string EndDate = dateTimePicker2.Value.ToString("yyyMMdd");
            string SQLString = "";
            SQLString = (@"SELECT * FROM DRINK_ITEMSLINE WHERE DATE > '" + StartDate + "' AND DATE < '"+ EndDate+"'");

           DataSet dataset = new DataSet();
            SqlConnection connection = new SqlConnection(Module_SQL.SQLConnectionString);
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = new SqlCommand(SQLString, connection);
            adapter.Fill(dataset);

            connection.Close();
            connection.Dispose();

            string Name;
            string Brand;
            string Price;
            string Date;
            string location;
            string Type;
            string Size;
            string LPrice;
            string OnSale;
            string Barcode;
            string SalePrice;
            int i;
            string DataColes = "";
            for (i = 1; i <= dataset.Tables[0].Rows.Count; i++)

            {
                Name = dataset.Tables[0].Rows[i][2].ToString();
                Brand = dataset.Tables[0].Rows[i][3].ToString();
                Price = dataset.Tables[0].Rows[i][4].ToString();
                Date = dataset.Tables[0].Rows[i][5].ToString();
                location = dataset.Tables[0].Rows[i][6].ToString();
                Type = dataset.Tables[0].Rows[i][7].ToString();
                Size = dataset.Tables[0].Rows[i][8].ToString();
                LPrice = dataset.Tables[0].Rows[i][9].ToString();
                OnSale = dataset.Tables[0].Rows[i][10].ToString();
                Barcode = dataset.Tables[0].Rows[i][11].ToString();
                SalePrice = dataset.Tables[0].Rows[i][12].ToString();

                DataColes = DataColes + "Name: "+Name+" Brand: "+Brand+" Price: " +Date+" Location: "+ location+" Type: " +Type+" Size: "+Size+" LPrice: "+LPrice+" OnSale: "+OnSale+ " Barcode: " +Barcode+" SalePrice: "+SalePrice;

            }

            






        }

        private void button2_Click(object sender, EventArgs e)
        {
            string SQLString = "";
            SQLString = (@"SELECT * FROM DRINK_ITEMSLINE");

            DataSet dataset = new DataSet();
            SqlConnection connection = new SqlConnection(Module_SQL.SQLConnectionString);
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = new SqlCommand(SQLString, connection);
            adapter.Fill(dataset);

            connection.Close();
            connection.Dispose();

            string Name;
            string Brand;
            string Price;
            string Date;
            string location;
            string Type;
            string Size;
            string LPrice;
            string OnSale;
            string Barcode;
            string SalePrice;
            string DataWW = "";
            int i;
            for (i = 1; i <= dataset.Tables[0].Rows.Count; i++)
            {
                Name = dataset.Tables[0].Rows[i][2].ToString();
                Brand = dataset.Tables[0].Rows[i][3].ToString();
                Price = dataset.Tables[0].Rows[i][4].ToString();
                Date = dataset.Tables[0].Rows[i][5].ToString();
                location = dataset.Tables[0].Rows[i][6].ToString();
                Type = dataset.Tables[0].Rows[i][7].ToString();
                Size = dataset.Tables[0].Rows[i][8].ToString();
                LPrice = dataset.Tables[0].Rows[i][9].ToString();
                OnSale = dataset.Tables[0].Rows[i][10].ToString();
                Barcode = dataset.Tables[0].Rows[i][11].ToString();
                SalePrice = dataset.Tables[0].Rows[i][12].ToString();

                DataWW = DataWW + "Name: " + Name + " Brand: " + Brand + " Price: " + Date + " Location: " + location + " Type: " + Type + " Size: " + Size + " LPrice: " + LPrice + " OnSale: " + OnSale + " Barcode: " + Barcode + " SalePrice: " + SalePrice;

            }

        }

    }
}




