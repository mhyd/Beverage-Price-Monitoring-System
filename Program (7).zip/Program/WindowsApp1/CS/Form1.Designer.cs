// VBConversions Note: VB project level imports
using System.Collections.Generic;
using System;
using System.Linq;
using System.Drawing;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Data;
using System.Xml.Linq;
using Microsoft.VisualBasic;
using System.Collections;
using System.Windows.Forms;
// End of VB project level imports


namespace WindowsApp1
{
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]public 
	partial class Form1 : System.Windows.Forms.Form
	{
		
		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}
		
		//Required by the Windows Form Designer
		private System.ComponentModel.Container components = null;
		
		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]private void InitializeComponent()
		{
            this.SQLSaveButton = new System.Windows.Forms.Button();
            this.SQLConnection = new System.Windows.Forms.GroupBox();
            this.SQLTestConnectionButton = new System.Windows.Forms.Button();
            this.FillOutThingsLabel = new System.Windows.Forms.Label();
            this.SQLUserNameLabel = new System.Windows.Forms.Label();
            this.SQLTickPictureBox = new System.Windows.Forms.PictureBox();
            this.SQLPassTextBox = new System.Windows.Forms.TextBox();
            this.SQLDatabaseLabel = new System.Windows.Forms.Label();
            this.SQLUserNameTextBox = new System.Windows.Forms.TextBox();
            this.SQLPassLabel = new System.Windows.Forms.Label();
            this.SQLDatabaseTextBox = new System.Windows.Forms.TextBox();
            this.SQLServerLabel = new System.Windows.Forms.Label();
            this.SQLServerTextBox = new System.Windows.Forms.TextBox();
            this.ConnectionToSQLLabel = new System.Windows.Forms.Label();
            this.SQLCROSSPictureBox = new System.Windows.Forms.PictureBox();
            this.SaveDataToDatabasebutton = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button3 = new System.Windows.Forms.Button();
            this.SQLConnection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SQLTickPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SQLCROSSPictureBox)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // SQLSaveButton
            // 
            this.SQLSaveButton.Location = new System.Drawing.Point(371, 188);
            this.SQLSaveButton.Name = "SQLSaveButton";
            this.SQLSaveButton.Size = new System.Drawing.Size(75, 23);
            this.SQLSaveButton.TabIndex = 62;
            this.SQLSaveButton.Text = "Save";
            this.SQLSaveButton.UseVisualStyleBackColor = true;
            this.SQLSaveButton.Click += new System.EventHandler(this.SQLSaveButton_Click);
            // 
            // SQLConnection
            // 
            this.SQLConnection.Controls.Add(this.SQLTestConnectionButton);
            this.SQLConnection.Controls.Add(this.FillOutThingsLabel);
            this.SQLConnection.Controls.Add(this.SQLUserNameLabel);
            this.SQLConnection.Controls.Add(this.SQLTickPictureBox);
            this.SQLConnection.Controls.Add(this.SQLPassTextBox);
            this.SQLConnection.Controls.Add(this.SQLDatabaseLabel);
            this.SQLConnection.Controls.Add(this.SQLUserNameTextBox);
            this.SQLConnection.Controls.Add(this.SQLPassLabel);
            this.SQLConnection.Controls.Add(this.SQLDatabaseTextBox);
            this.SQLConnection.Controls.Add(this.SQLServerLabel);
            this.SQLConnection.Controls.Add(this.SQLServerTextBox);
            this.SQLConnection.Controls.Add(this.ConnectionToSQLLabel);
            this.SQLConnection.Controls.Add(this.SQLCROSSPictureBox);
            this.SQLConnection.Location = new System.Drawing.Point(6, 6);
            this.SQLConnection.Name = "SQLConnection";
            this.SQLConnection.Size = new System.Drawing.Size(359, 205);
            this.SQLConnection.TabIndex = 61;
            this.SQLConnection.TabStop = false;
            this.SQLConnection.Text = "SQL Connection";
            // 
            // SQLTestConnectionButton
            // 
            this.SQLTestConnectionButton.Location = new System.Drawing.Point(305, 136);
            this.SQLTestConnectionButton.Name = "SQLTestConnectionButton";
            this.SQLTestConnectionButton.Size = new System.Drawing.Size(38, 23);
            this.SQLTestConnectionButton.TabIndex = 60;
            this.SQLTestConnectionButton.Text = "Test";
            this.SQLTestConnectionButton.UseVisualStyleBackColor = true;
            this.SQLTestConnectionButton.Click += new System.EventHandler(this.SQLTestConnectionButton_Click);
            // 
            // FillOutThingsLabel
            // 
            this.FillOutThingsLabel.AutoSize = true;
            this.FillOutThingsLabel.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.FillOutThingsLabel.Location = new System.Drawing.Point(9, 181);
            this.FillOutThingsLabel.Name = "FillOutThingsLabel";
            this.FillOutThingsLabel.Size = new System.Drawing.Size(122, 13);
            this.FillOutThingsLabel.TabIndex = 59;
            this.FillOutThingsLabel.Text = "* Please Fill out all Fields";
            // 
            // SQLUserNameLabel
            // 
            this.SQLUserNameLabel.AutoSize = true;
            this.SQLUserNameLabel.Location = new System.Drawing.Point(6, 82);
            this.SQLUserNameLabel.Name = "SQLUserNameLabel";
            this.SQLUserNameLabel.Size = new System.Drawing.Size(87, 13);
            this.SQLUserNameLabel.TabIndex = 53;
            this.SQLUserNameLabel.Text = "SQL User Name:";
            // 
            // SQLTickPictureBox
            // 
            this.SQLTickPictureBox.Image = global::My.Resources.Resources.Tick;
            this.SQLTickPictureBox.Location = new System.Drawing.Point(269, 131);
            this.SQLTickPictureBox.Name = "SQLTickPictureBox";
            this.SQLTickPictureBox.Size = new System.Drawing.Size(30, 32);
            this.SQLTickPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SQLTickPictureBox.TabIndex = 49;
            this.SQLTickPictureBox.TabStop = false;
            // 
            // SQLPassTextBox
            // 
            this.SQLPassTextBox.Location = new System.Drawing.Point(149, 105);
            this.SQLPassTextBox.Name = "SQLPassTextBox";
            this.SQLPassTextBox.Size = new System.Drawing.Size(194, 20);
            this.SQLPassTextBox.TabIndex = 58;
            // 
            // SQLDatabaseLabel
            // 
            this.SQLDatabaseLabel.AutoSize = true;
            this.SQLDatabaseLabel.Location = new System.Drawing.Point(6, 53);
            this.SQLDatabaseLabel.Name = "SQLDatabaseLabel";
            this.SQLDatabaseLabel.Size = new System.Drawing.Size(111, 13);
            this.SQLDatabaseLabel.TabIndex = 52;
            this.SQLDatabaseLabel.Text = "SQL Database Name:";
            // 
            // SQLUserNameTextBox
            // 
            this.SQLUserNameTextBox.Location = new System.Drawing.Point(149, 79);
            this.SQLUserNameTextBox.Name = "SQLUserNameTextBox";
            this.SQLUserNameTextBox.Size = new System.Drawing.Size(194, 20);
            this.SQLUserNameTextBox.TabIndex = 57;
            // 
            // SQLPassLabel
            // 
            this.SQLPassLabel.AutoSize = true;
            this.SQLPassLabel.Location = new System.Drawing.Point(6, 108);
            this.SQLPassLabel.Name = "SQLPassLabel";
            this.SQLPassLabel.Size = new System.Drawing.Size(80, 13);
            this.SQLPassLabel.TabIndex = 54;
            this.SQLPassLabel.Text = "SQL Password:";
            // 
            // SQLDatabaseTextBox
            // 
            this.SQLDatabaseTextBox.Location = new System.Drawing.Point(149, 50);
            this.SQLDatabaseTextBox.Name = "SQLDatabaseTextBox";
            this.SQLDatabaseTextBox.Size = new System.Drawing.Size(194, 20);
            this.SQLDatabaseTextBox.TabIndex = 56;
            // 
            // SQLServerLabel
            // 
            this.SQLServerLabel.AutoSize = true;
            this.SQLServerLabel.Location = new System.Drawing.Point(6, 27);
            this.SQLServerLabel.Name = "SQLServerLabel";
            this.SQLServerLabel.Size = new System.Drawing.Size(96, 13);
            this.SQLServerLabel.TabIndex = 51;
            this.SQLServerLabel.Text = "SQL Server Name:";
            // 
            // SQLServerTextBox
            // 
            this.SQLServerTextBox.Location = new System.Drawing.Point(149, 24);
            this.SQLServerTextBox.Name = "SQLServerTextBox";
            this.SQLServerTextBox.Size = new System.Drawing.Size(194, 20);
            this.SQLServerTextBox.TabIndex = 55;
            // 
            // ConnectionToSQLLabel
            // 
            this.ConnectionToSQLLabel.AutoSize = true;
            this.ConnectionToSQLLabel.Location = new System.Drawing.Point(6, 141);
            this.ConnectionToSQLLabel.Name = "ConnectionToSQLLabel";
            this.ConnectionToSQLLabel.Size = new System.Drawing.Size(100, 13);
            this.ConnectionToSQLLabel.TabIndex = 50;
            this.ConnectionToSQLLabel.Text = "Connection to SQL:";
            // 
            // SQLCROSSPictureBox
            // 
            this.SQLCROSSPictureBox.Image = global::My.Resources.Resources.cross;
            this.SQLCROSSPictureBox.Location = new System.Drawing.Point(269, 131);
            this.SQLCROSSPictureBox.Name = "SQLCROSSPictureBox";
            this.SQLCROSSPictureBox.Size = new System.Drawing.Size(30, 32);
            this.SQLCROSSPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SQLCROSSPictureBox.TabIndex = 48;
            this.SQLCROSSPictureBox.TabStop = false;
            this.SQLCROSSPictureBox.Visible = false;
            // 
            // SaveDataToDatabasebutton
            // 
            this.SaveDataToDatabasebutton.Location = new System.Drawing.Point(6, 217);
            this.SaveDataToDatabasebutton.Name = "SaveDataToDatabasebutton";
            this.SaveDataToDatabasebutton.Size = new System.Drawing.Size(131, 23);
            this.SaveDataToDatabasebutton.TabIndex = 63;
            this.SaveDataToDatabasebutton.Text = "Save Coles Data";
            this.SaveDataToDatabasebutton.UseVisualStyleBackColor = true;
            this.SaveDataToDatabasebutton.Click += new System.EventHandler(this.SaveDataToDatabasebutton_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(2, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(502, 428);
            this.tabControl1.TabIndex = 64;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.SQLConnection);
            this.tabPage1.Controls.Add(this.SaveDataToDatabasebutton);
            this.tabPage1.Controls.Add(this.SQLSaveButton);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(494, 402);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "SQL Connection";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(494, 402);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Load From Database";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Location = new System.Drawing.Point(7, 132);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(481, 74);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Download All";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Download All:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(99, 21);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 45);
            this.button2.TabIndex = 0;
            this.button2.Text = "Download File";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(482, 119);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Download By Date";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(287, 34);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 46);
            this.button1.TabIndex = 4;
            this.button1.Text = "Download File";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Start Date:";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(80, 60);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "End Date:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(80, 34);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(7, 247);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(130, 23);
            this.button3.TabIndex = 64;
            this.button3.Text = "Save Woolworths Data";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 434);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.SQLConnection.ResumeLayout(false);
            this.SQLConnection.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SQLTickPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SQLCROSSPictureBox)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

		}
		
		internal Button SQLSaveButton;
		internal GroupBox SQLConnection;
		internal Button SQLTestConnectionButton;
		internal Label FillOutThingsLabel;
		internal Label SQLUserNameLabel;
		internal PictureBox SQLTickPictureBox;
		internal TextBox SQLPassTextBox;
		internal Label SQLDatabaseLabel;
		internal TextBox SQLUserNameTextBox;
		internal Label SQLPassLabel;
		internal TextBox SQLDatabaseTextBox;
		internal Label SQLServerLabel;
		internal TextBox SQLServerTextBox;
		internal Label ConnectionToSQLLabel;
		internal PictureBox SQLCROSSPictureBox;
        private Button SaveDataToDatabasebutton;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private GroupBox groupBox1;
        private Button button1;
        private Label label1;
        private DateTimePicker dateTimePicker2;
        private Label label2;
        private DateTimePicker dateTimePicker1;
        private GroupBox groupBox2;
        private Label label3;
        private Button button2;
        private Button button3;
    }
	
}
