// VBConversions Note: VB project level imports
using System.Collections.Generic;
using System;
using System.Linq;
using System.Drawing;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Data;
using System.Xml.Linq;
using Microsoft.VisualBasic;
using System.Collections;
using System.Windows.Forms;
// End of VB project level imports

using System.Runtime.InteropServices;

namespace WindowsApp1
{
	
	
	//INI File class from article:
	//INI Files Will Never Die: How-To in .NET
	//By Karl Moore
	//http://www.developer.com/net/asp/article.php/3287991
	//Example Usage: Dim objIniFile As New IniFile("c:\data.ini")
	//objIniFile.WriteString("Settings", "ClockTime", "12:59")
	//Dim strData As String = objIniFile.GetString("Settings", "ClockTime", "(none)")
	
	public class IniFile
	{
		// API functions
		[DllImport("kernel32.dll",EntryPoint="GetPrivateProfileStringA", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
			private static extern int GetPrivateProfileString(string lpApplicationName, string lpKeyName, string lpDefault, System.Text.StringBuilder lpReturnedString, int nSize, string lpFileName);
		[DllImport("kernel32.dll",EntryPoint="WritePrivateProfileStringA", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
			private static extern int WritePrivateProfileString(string lpApplicationName, string lpKeyName, string lpString, string lpFileName);
		[DllImport("kernel32.dll",EntryPoint="GetPrivateProfileIntA", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
			private static extern int GetPrivateProfileInt(string lpApplicationName, string lpKeyName, int nDefault, string lpFileName);
		[DllImport("kernel32.dll",EntryPoint="WritePrivateProfileStringA", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
			private static extern int FlushPrivateProfileString(int lpApplicationName, int lpKeyName, int lpString, string lpFileName);
		string strFilename;
		
		// Constructor, accepting a filename
		public IniFile(string Filename)
		{
			strFilename = Filename;
		}
		
		// Read-only filename property
		public string FileName
		{
			get
			{
				return strFilename;
			}
		}
		
		public string GetString(string Section, string Key, string Default)
		{
			string returnValue = "";
			// Returns a string from your INI file
			int intCharCount = 0;
			System.Text.StringBuilder objResult = new System.Text.StringBuilder(256);
			intCharCount = System.Convert.ToInt32(GetPrivateProfileString(Section, Key,
				Default, objResult, objResult.Capacity, strFilename));
			if (intCharCount > 0)
			{
				returnValue = objResult.ToString().Substring(0, intCharCount);
			}
			else
			{
				return "";
			}
			return returnValue;
		}
		
		public int GetInteger(string Section, string Key, int Default)
			{
			// Returns an integer from your INI file
			return GetPrivateProfileInt(Section, Key,
				Default, strFilename);
		}
		
		public bool GetBoolean(string Section, string Key, bool Default)
			{
			// Returns a boolean from your INI file
			int INIValue = 0;
			INIValue = System.Convert.ToInt32(GetPrivateProfileInt(Section, Key, System.Convert.ToInt32(Default), strFilename));
			return System.Math.Abs(INIValue) == 1;
			
		}
		
		public void WriteString(string Section, string Key, string Value)
			{
			// Writes a string to your INI file
			WritePrivateProfileString(Section, Key, Value, strFilename);
			Flush();
		}
		
		public void WriteInteger(string Section, string Key, int Value)
			{
			// Writes an integer to your INI file
			WriteString(Section, Key, (Value).ToString());
			Flush();
		}
		
		public void WriteBoolean(string Section, string Key, bool Value)
			{
			// Writes a boolean to your INI file
			WriteString(Section, Key, (System.Convert.ToInt32(Value)).ToString());
			Flush();
		}
		
		private void Flush()
		{
			// Stores all the cached changes to your INI file
			FlushPrivateProfileString(0, 0, 0, strFilename);
		}
		
	}
}
