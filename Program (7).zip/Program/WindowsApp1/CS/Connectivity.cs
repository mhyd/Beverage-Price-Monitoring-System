// VBConversions Note: VB project level imports
using System.Collections.Generic;
using System;
using System.Linq;
using System.Drawing;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Data;
using System.Xml.Linq;
using Microsoft.VisualBasic;
using System.Collections;
using System.Windows.Forms;
// End of VB project level imports


namespace WindowsApp1
{
	
	public class Connectivity
	{
		
		public static bool IsInternetConnectionAvailable(string TestURL)
		{
			// Test Internet Connectivity
			
			//   typically use "http://www.google.com.au/"
			//Call url
			System.Uri url = new System.Uri(TestURL);
			//Request for request
			System.Net.WebRequest req = default(System.Net.WebRequest);
			req = System.Net.WebRequest.Create(url);
			System.Net.WebResponse resp = default(System.Net.WebResponse);
			try
			{
				resp = req.GetResponse();
				resp.Close();
				req = null;
				return true;
			}
			catch (Exception)
			{
				req = null;
				return false;
			}
		}
		
		public static bool IsSQLConnectionOK(string Server, string Database, string Username, string Password)
			{
			
			string ConnectionString = "";
			ConnectionString = SQLConnectionString(Server, Database, Username, Password);
			
			try // try connecting to the SQL server
			{
				System.Data.OleDb.OleDbConnection oledbConn = new System.Data.OleDb.OleDbConnection(ConnectionString);
				oledbConn.Open();
				
				oledbConn.Close();
				// SQL Connection must be ok, so proceed.
				return true;
				
			}
			catch (Exception)
			{
				// SQL Connection Failure
				return false;
			}
			
		}
		
		
		public static string SQLConnectionString(string Server, string Database, string Username, string Password)
			{

            

            string SQLConnString = "";
            SQLConnString = "Provider=SQLOLEDB;";
            SQLConnString = SQLConnString + "data source =" + Server + ";";
            SQLConnString = SQLConnString + "initial catalog = " + Database + ";";
            SQLConnString = SQLConnString + "USER ID=" + Username + ";";
            SQLConnString = SQLConnString + "Password=" + Password + ";";
			
			return SQLConnString;
			
		}
		
		
	}
}
